-- BharatVera: run once in Supabase > SQL Editor. Uses bv_ prefix so it won't clash with existing tables.
create sequence bv_order_seq; create sequence bv_timing_seq; create sequence bv_feedback_seq;

create table bv_profiles(id uuid primary key references auth.users on delete cascade, email text not null, name text, phone text,
  role text not null default 'Customer' check (role in ('Customer','Admin')));

create table bv_orders(
  order_id text primary key default 'O'||lpad(nextval('bv_order_seq')::text,3,'0'),
  user_email text not null default (auth.jwt()->>'email'),
  order_type text not null check (order_type in ('Food','Grocery')),
  items_summary text not null,
  order_date timestamptz not null default now(),
  order_status text not null default 'New' check (order_status in ('New','Accepted','Preparing','Ready for pickup','Picked up','Out for delivery','Delivered','Cancelled')),
  delivery_note text, status_note text,
  accepted_at timestamptz, preparing_at timestamptz, ready_at timestamptz, picked_up_at timestamptz,
  out_for_delivery_at timestamptz, delivered_at timestamptz, cancelled_at timestamptz);

create table bv_order_timings(
  timing_id text primary key default 'T'||lpad(nextval('bv_timing_seq')::text,3,'0'),
  order_id text not null references bv_orders on delete cascade, order_status text not null,
  event_time timestamptz not null default now(), updated_by text, note text);

create table bv_feedbacks(
  feedback_id text primary key default 'F'||lpad(nextval('bv_feedback_seq')::text,3,'0'),
  order_id text not null unique references bv_orders on delete cascade,
  rating int not null check (rating between 1 and 5), feedback_note text,
  submitted_at timestamptz not null default now(), submitted_by text);

-- helper: is the current user an admin?
create function bv_is_admin() returns boolean language sql stable security definer set search_path=public as
$$ select exists(select 1 from bv_profiles where id=auth.uid() and role='Admin') $$;

-- auto-create profile on signup
create function bv_handle_new_user() returns trigger language plpgsql security definer set search_path=public as
$$ begin insert into bv_profiles(id,email,name,phone) values(new.id,new.email,new.raw_user_meta_data->>'name',new.raw_user_meta_data->>'phone'); return new; end $$;
create trigger bv_on_signup after insert on auth.users for each row execute function bv_handle_new_user();

-- stamp status timestamps + write the OrderTimings row automatically
create function bv_stamp() returns trigger language plpgsql security definer set search_path=public as $$
begin
  if new.order_status is distinct from old.order_status then
    case new.order_status
      when 'Accepted' then new.accepted_at=now(); when 'Preparing' then new.preparing_at=now();
      when 'Ready for pickup' then new.ready_at=now(); when 'Picked up' then new.picked_up_at=now();
      when 'Out for delivery' then new.out_for_delivery_at=now(); when 'Delivered' then new.delivered_at=now();
      when 'Cancelled' then new.cancelled_at=now(); else null end case;
  end if; return new; end $$;
create trigger bv_stamp_t before update on bv_orders for each row execute function bv_stamp();

create function bv_log() returns trigger language plpgsql security definer set search_path=public as $$
begin
  if tg_op='INSERT' or new.order_status is distinct from old.order_status then
    insert into bv_order_timings(order_id,order_status,updated_by,note) values(new.order_id,new.order_status,auth.jwt()->>'email',
      case when tg_op='INSERT' then 'Order placed' else new.status_note end);
  end if; return new; end $$;
create trigger bv_log_t after insert or update on bv_orders for each row execute function bv_log();

-- security: customers see only their own rows, admins see everything
alter table bv_profiles enable row level security; alter table bv_orders enable row level security;
alter table bv_order_timings enable row level security; alter table bv_feedbacks enable row level security;

create policy p_prof_sel on bv_profiles for select using (id=auth.uid() or bv_is_admin());
create policy p_ord_sel on bv_orders for select using (user_email=auth.jwt()->>'email' or bv_is_admin());
create policy p_ord_ins on bv_orders for insert with check (user_email=auth.jwt()->>'email' and order_status='New');
create policy p_ord_upd on bv_orders for update using (bv_is_admin()) with check (bv_is_admin());
create policy p_tim_sel on bv_order_timings for select using (bv_is_admin() or exists(select 1 from bv_orders o where o.order_id=bv_order_timings.order_id and o.user_email=auth.jwt()->>'email'));
create policy p_fb_sel on bv_feedbacks for select using (bv_is_admin() or submitted_by=auth.jwt()->>'email');
create policy p_fb_ins on bv_feedbacks for insert with check (submitted_by=auth.jwt()->>'email' and exists(select 1 from bv_orders o where o.order_id=bv_feedbacks.order_id and o.user_email=auth.jwt()->>'email' and o.order_status='Delivered'));
create policy p_fb_upd on bv_feedbacks for update using (submitted_by=auth.jwt()->>'email') with check (submitted_by=auth.jwt()->>'email');

-- AFTER you sign up your own account in the app, make yourself admin:
-- update bv_profiles set role='Admin' where email='you@example.com';
