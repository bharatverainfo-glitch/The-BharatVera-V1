// BharatVera configuration.
// Leave SUPABASE_URL empty to run the app in DEMO mode (data stays in this browser only).
// Demo admin login: admin@bharatvera.in / admin123
window.BV_CONFIG = {
  SUPABASE_URL: "",       // e.g. https://xxxx.supabase.co
  SUPABASE_ANON_KEY: "",  // public anon / publishable key (safe in the browser)
  NOTIFY_URL: "",         // optional: receives POST {to, subject, body} to send email/push
  GA_ID: "",              // Google Analytics ID, e.g. G-XXXXXXXXXX (analytics is off while empty)
  FORM_URL: ""            // contact form endpoint, e.g. https://formspree.io/f/xxxxxxx (messages stay in this browser while empty)
};
